import telebot
import os
import time
import logging

logging.basicConfig(level=logging.INFO)

TOKEN = '7125986722:AAEyhba2EqMC6bWQ-PVtPjP1xJkRszikZs4'
ADMIN_ID = 7125986722

bot = telebot.TeleBot(TOKEN)
user_dict = {}

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Привет! Напиши свой вопрос, и я передам его оператору.")

@bot.message_handler(func=lambda msg: True)
def forward_to_admin(message):
    try:
        user_id = message.chat.id
        forwarded = bot.forward_message(ADMIN_ID, user_id, message.message_id)
        user_dict[forwarded.message_id] = user_id
        logging.info(f"Forwarded message from {user_id} to admin")
    except Exception as e:
        logging.error(f"Error forwarding message: {e}")

@bot.message_handler(func=lambda msg: msg.reply_to_message is not None and msg.chat.id == ADMIN_ID)
def reply_to_user(message):
    try:
        original_msg_id = message.reply_to_message.message_id
        if original_msg_id in user_dict:
            user_id = user_dict[original_msg_id]
            bot.send_message(user_id, message.text)
            logging.info(f"Sent reply to user {user_id}")
    except Exception as e:
        logging.error(f"Error sending reply: {e}")

def main():
    while True:
        try:
            bot.polling(none_stop=True)
        except Exception as e:
            logging.error(f"Polling error: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
